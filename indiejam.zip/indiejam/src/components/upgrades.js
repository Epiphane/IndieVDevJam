Juicy.Component.create('Upgrades', {
    constructor: function() {
        this.heavy = true;
    },

    update: function(dt, input) {
    },
});
