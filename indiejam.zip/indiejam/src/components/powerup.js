Juicy.Component.create('Powerup', {
   
});