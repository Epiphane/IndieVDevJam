var ParticleManager = Juicy.Entity.extend({
    components: ['Particles'],
    init: function() {
        this.particles = [];
    },

    update: function() {

    }
});
