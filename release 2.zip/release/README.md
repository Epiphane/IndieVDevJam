# IndieVDevJam

We're using [JuicyJS](https://github.com/Epiphane/juicyjs). Nuff said.