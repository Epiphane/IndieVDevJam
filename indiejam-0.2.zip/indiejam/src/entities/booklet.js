var Booklet = Juicy.Entity.extend({
   components: ['Box', 'Booklet'],
   init: function() {
      this.transform.width = 0.8;
      this.transform.height = 0.6;
   }
});
