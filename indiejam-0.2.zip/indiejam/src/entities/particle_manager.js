var ParticleManager = Juicy.Entity.extend({
    components: ['ParticleManager'],
    init: function() {
        this.particles = [];
    },

    update: function() {

    }
});
